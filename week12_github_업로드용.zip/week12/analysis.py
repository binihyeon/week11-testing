import pandas as pd
from pathlib import Path


def 정제(df: pd.DataFrame) -> pd.DataFrame:
    """명세서에 따라 성적 DataFrame을 4단계로 정제하여 반환한다."""
    # 원본 df를 직접 수정하지 않도록 복사본을 생성한다.
    df = df.copy()
    print("시작        ", len(df))

    # 1) 점수가 비어 있는(결측치) 행을 삭제한다.
    df = df.dropna(subset=["점수"])
    print("빈 칸 제거  ", len(df))

    # 2) 모든 열이 완전히 같은 중복 행은 하나만 남기고 삭제한다.
    df = df.drop_duplicates()
    print("중복 제거   ", len(df))

    # 3) 반과 과목 문자열 앞뒤에 섞인 공백을 제거한다.
    df["반"] = df["반"].str.strip()
    df["과목"] = df["과목"].str.strip()

    # 4) 점수가 유효 범위(0 이상 100 이하) 밖인 행을 삭제한다.
    df = df[(df["점수"] >= 0) & (df["점수"] <= 100)]
    print("범위 밖 제거", len(df))

    return df


def 반별평균(df: pd.DataFrame) -> dict:
    """반 이름을 키로 하는 점수 평균 딕셔너리를 반환한다."""
    return df.groupby("반")["점수"].mean().round(2).to_dict()


if __name__ == "__main__":
    base_dir = Path(__file__).parent
    raw_df = pd.read_csv(base_dir / "scores_2026.csv")

    print("=== [STEP 1] 정제 전 원본 진단 ===")
    print("전체 행·열:", raw_df.shape)
    print("점수 빈 칸 수:", int(raw_df["점수"].isna().sum()))
    print("완전 중복 행 수:", int(raw_df.duplicated().sum()))
    print("반 이름 종류:", raw_df["반"].unique().tolist())
    print("과목 이름 종류:", raw_df["과목"].unique().tolist())
    print(f"점수 최소·최대: {raw_df['점수'].min()} ~ {raw_df['점수'].max()}")

    print("\n=== [STEP 2] 데이터 정제 ===")
    clean_df = 정제(raw_df)
    print("정제 후 반 종류:", sorted(clean_df["반"].unique().tolist()))
    print("정제 후 과목 종류:", sorted(clean_df["과목"].unique().tolist()))

    print("\n=== [STEP 3-1] 필터링 ===")
    math_df = clean_df[clean_df["과목"] == "수학"]
    print("과목이 '수학'인 행 수:", len(math_df))
    high_class1_df = clean_df[(clean_df["반"] == "1반") & (clean_df["점수"] >= 90)]
    print("1반이면서 90점 이상인 행 수:", len(high_class1_df))

    print("\n=== [STEP 3-2] 그룹화 ===")
    print("[반별 평균]")
    print(clean_df.groupby("반")["점수"].mean().round(2))
    print("\n[과목 × 반 평균]")
    print(clean_df.groupby(["과목", "반"])["점수"].mean().round(2))

    print("\n=== [STEP 3-3] 반별 요약 통계 ===")
    summary_stats = clean_df.groupby("반")["점수"].agg(["count", "mean", "median", "max"]).round(2)
    print(summary_stats)

    print("\n=== [STEP 4] 검증 (합계 일치 · 개수 일치 · 스팟 체크) ===")
    group_sum = clean_df.groupby("반")["점수"].sum().sum()
    total_sum = clean_df["점수"].sum()
    group_count = clean_df.groupby("반")["점수"].count().sum()
    total_count = len(clean_df)
    spot_scores = clean_df[(clean_df["반"] == "1반") & (clean_df["과목"] == "수학")]["점수"]
    print(f"합계 일치: {group_sum} == {total_sum} ({group_sum == total_sum})")
    print(f"개수 일치: {group_count} == {total_count} ({group_count == total_count})")
    print(f"스팟 체크(1반 수학 {len(spot_scores)}명): 값={spot_scores.tolist()}, 평균={spot_scores.mean()}")
