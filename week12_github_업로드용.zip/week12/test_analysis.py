import sys
from pathlib import Path
import pandas as pd

# 실행 위치(루트 또는 week12 폴더)와 무관하게 analysis 모듈과 CSV를 불러올 수 있도록 경로 설정
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from analysis import 정제, 반별평균

본 = 정제(pd.read_csv(BASE_DIR / "scores_2026.csv"))
미니 = 정제(pd.read_csv(BASE_DIR / "mini.csv"))


def test_정제하면_100행이_남는다():
    """검증 ① 행 수 보존: 정제 후 정확히 100행이 남아야 한다."""
    assert len(본) == 100


def test_반은_두_종류만_남는다():
    """검증 ① 정합성: 공백 제거 후 반 이름은 '1반'과 '2반' 두 종류뿐이어야 한다."""
    assert sorted(본["반"].unique()) == ["1반", "2반"]


def test_그룹합이_전체합과_같다():
    """검증 ② 합계 일치: 반별 점수 합계의 합과 전체 점수 합계가 일치해야 한다."""
    assert 본.groupby("반")["점수"].sum().sum() == 본["점수"].sum()


def test_손계산과_일치한다():
    """검증 ③ 손계산 대조: mini.csv 정제 후 1반 평균이 손계산 결과(80.0)와 같아야 한다."""
    assert 반별평균(미니)["1반"] == 80.0
